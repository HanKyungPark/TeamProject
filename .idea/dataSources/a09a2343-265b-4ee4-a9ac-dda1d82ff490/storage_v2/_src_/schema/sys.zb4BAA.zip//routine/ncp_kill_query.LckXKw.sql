create
    definer = radmin@localhost procedure ncp_kill_query(IN queryID bigint)
BEGIN
   DECLARE mysql_version VARCHAR(20);
   DECLARE system_user_yn INT;
   DECLARE exist_yn INT;
   DECLARE called_by_user VARCHAR(50);
   DECLARE priv_yn VARCHAR(5);
   DECLARE v_user VARCHAR(20);
   DECLARE v_host VARCHAR(50);
   DECLARE hostname VARCHAR(50);
   DECLARE result VARCHAR(10);
   DECLARE messageText VARCHAR(400);

   SELECT user() into called_by_user;
   SELECT version() into mysql_version;
   SELECT user, host into v_user, v_host FROM mysql.user WHERE USER() LIKE concat(USER,'@',HOST) ORDER BY LENGTH(HOST) - LENGTH(REPLACE(HOST,'.','')) DESC , substring_index(REPLACE(REPLACE(host,'_',''),'%',''), '.',-1) desc LIMIT 1 ;
   SELECT @@hostname into hostname;

   SET @v_user := v_user;
   SET @v_host := v_host;
   SET @queryID := queryID;
   SET result= 'FAIL';

   SET @sql_db:=CONCAT('KILL QUERY ',@queryID);


   SELECT count(*) as CNT FROM information_schema.processlist WHERE id = queryID INTO exist_yn;
   SELECT count(*) as CNT FROM information_schema.processlist WHERE User NOT IN ('agent','radmin','ha_admin','repl_admin','system user') AND id = queryID INTO system_user_yn;
   SELECT `Repl_slave_priv` FROM mysql.user WHERE user= SUBSTRING_INDEX(user(), '@', 1) AND host= v_host LIMIT 1 INTO priv_yn;

      IF priv_yn ='Y' THEN
         IF exist_yn = 1 THEN
               IF system_user_yn >= 1 THEN
                   PREPARE stmt_db FROM @sql_db;
                   EXECUTE stmt_db;
                   SELECT '[Success] Successfully Kill Query.' as Message;
                   SET messageText='[Success] Successfully Kill Query.';
                   SET result= 'SUCCESS';
               ELSE
                   SELECT '[Fail] You cannot kill the process used for the system account.' as Message;
                   SET messageText='[Fail] You cannot kill the process used for the system account.';
               END IF;
         ELSE
             SELECT '[Fail] This is a nonexistent processlist id.' as Message;
             SET messageText='[Fail] This is a nonexistent processlist id.';
         END IF;
     ELSE
        SELECT '[Fail] You have no authority to Kill Query. Please try again with an account with DDL privileges.' as Message;
        SET messageText='[Fail] You have no authority to Kill Query. Please try again with an account with DDL privileges.';
     END IF;
      SET sql_log_bin = 0;
      INSERT INTO mysql.ncp_db_history (`hostname`, `version`, `called_by_user`, `action`, `db_name`,  `result`, `message`) values ( hostname, mysql_version, called_by_user, "KILL QUERY", '', result , CONCAT("KILL QUERY ", queryID, " / " ,messageText));
      SET sql_log_bin = 1;
 END;

