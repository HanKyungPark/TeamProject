create
    definer = radmin@localhost procedure ncp_create_db(IN db_name varchar(50), IN db_character_set varchar(50),
                                                       IN db_collation_set varchar(50))
BEGIN

    DECLARE mysql_version VARCHAR(20);
    DECLARE created_yn  INT;
    DECLARE called_by_user VARCHAR(50);
    DECLARE sql_logging BOOLEAN;
    DECLARE priv_yn VARCHAR(5);
    DECLARE v_user VARCHAR(20);
    DECLARE db_names VARCHAR(20);
    DECLARE read_yn INT;
    DECLARE verification INT;
    DECLARE verification_charset INT;
    DECLARE verification_collation INT;

    DECLARE hostname VARCHAR(50);
    DECLARE result VARCHAR(10);
    DECLARE messageText VARCHAR(400);
    DECLARE db_length INT;
    DECLARE v_host VARCHAR(50);
    DECLARE v_db_count INT;

    DECLARE db_character_text VARCHAR(100);
    DECLARE db_collation_text VARCHAR(100);

    SELECT @@hostname into hostname;
    SELECT @@SESSION.sql_log_bin into sql_logging;
    SELECT user() into called_by_user;

    SELECT user, host into v_user, v_host from mysql.user where USER() like concat(USER,'@',HOST) ORDER BY LENGTH(HOST) - LENGTH(REPLACE(HOST,'.','')) DESC , substring_index(REPLACE(REPLACE(host,'_',''),'%',''), '.',-1) desc LIMIT 1 ;

    SELECT version() into mysql_version;
    SELECT COUNT(1) into created_yn FROM information_schema.schemata  WHERE  lower(schema_name)= lower(db_name) ;
    SELECT count(1)  into v_db_count FROM information_schema.schemata ;

    SELECT @@global.read_only into read_yn;
    SELECT db_name  REGEXP '^[a-zA-Z][a-zA-Z0-9_]*$' into verification;
    SELECT db_character_set  REGEXP '^[a-zA-Z\s][a-zA-Z0-9_\s]*$'  or length(db_character_set)= 0 into verification_charset;
    SELECT db_collation_set  REGEXP '^[a-zA-Z\s][a-zA-Z0-9_\s]*$'  or length(db_collation_set)= 0 into verification_collation;

    SELECT LENGTH(db_name) into db_length;

    SET @db_name := db_name;
    SET @v_user := v_user;
    SET @v_host := v_host;
    SET @db_character_set := db_character_set;
    SET @db_collation_set := db_collation_set;
    SET result= 'FAIL';

    SET db_character_text='';
    SET db_collation_text='';

    SET @sql_db:=CONCAT('create database ',@db_name);
    SET @sql_user:=CONCAT('grant all privileges on ',@db_name,'.* to \'', @v_user,'\'@\'', @v_host, '\' with grant option');

    SELECT `Create_user_priv` FROM mysql.user WHERE user= SUBSTRING_INDEX(user(), '@', 1) and host= v_host LIMIT 1 into priv_yn;

       IF read_yn= 0 THEN
           IF sql_logging = 1 THEN
                IF db_name = '' THEN
                    SELECT '[Fail] Be sure to enter the DB name you want to create.' as Message;
                    SET messageText='[Fail] Be sure to enter the DB name you want to create.';
                ELSE
                    IF LOWER(db_character_set) != '' THEN
                        SET db_character_text :=CONCAT(' DEFAULT CHARACTER SET ',@db_character_set );
                    END IF;
                    IF  LOWER(db_collation_set) != '' THEN
                        SET db_collation_text :=CONCAT(' DEFAULT COLLATE ',@db_collation_set );
                    END IF;

                    SET @sql_db:=CONCAT('create database ',@db_name,db_character_text,db_collation_text);
                            IF db_length < 31 THEN
                            IF verification= 1 THEN
                                IF (verification_charset= 1 and verification_collation= 1) THEN
                                    IF priv_yn ='N' THEN
                                      SELECT '[Fail] You have no authority to create database. Please try again with an account with DDL privileges.' as Message;
                                      SET messageText='[Fail] You have no authority to create database. Please try again with an account with DDL privileges.';
                                    ELSE
                                    IF (priv_yn ='Y' and created_yn = 0) THEN
                                        PREPARE stmt_db FROM @sql_db;
                                        EXECUTE stmt_db;
                                        PREPARE stmt_user FROM @sql_user;
                                        EXECUTE stmt_user;

                                        SELECT COUNT(1) into created_yn FROM information_schema.schemata  WHERE lower(schema_name)= lower(db_name) ;
                                        IF (created_yn = 1) THEN
                                            SELECT '[Success] Successfully create database.' as Message;
                                            SET messageText='[Success] Successfully create database.';
                                            SET result= 'SUCCESS';
                                        ELSE
                                            SELECT '[Fail] Failed to create database.' as Message;
                                            SET messageText='[Fail] Failed to create database.';
                                        END IF;
                                    ELSE
                                    IF (priv_yn ='Y' and created_yn = 1) THEN
                                        SELECT '[Fail] Database is already created.' as Message;
                                        SET messageText='[Fail] Database is already created.';
                                    END IF;
                                END IF;
                            END IF;
                            ELSE
                                SELECT '[Fail] For CharacterSet/Collation name, only English alphabet, numbers, "_" are allowed. It must start with an alphabetic character.' as Message;
                                SET messageText='[Fail] For CharacterSet/Collation name, only English alphabet, numbers, "_" are allowed. It must start with an alphabetic character.';
                            END IF;
                        ELSE
                            SELECT '[Fail] For Database name, only English alphabet, numbers, "_" are allowed. It must start with an alphabetic character.' as Message;
                            SET messageText='[Fail] For Database name, only English alphabet, numbers, "_" are allowed. It must start with an alphabetic character.';
                        END IF;
                    ELSE
                        SELECT '[Fail] DB name is allowed up to 30 characters.' as Message;
                        SET messageText='[Fail] DB name is allowed up to 30 characters.';
                    END IF;
            END IF;
            INSERT INTO mysql.ncp_db_history (`hostname`, `version`, `called_by_user`, `action`, `db_name`, `db_character_set`, `db_collation_set`, `result`, `message`) values ( hostname, mysql_version, called_by_user, "CREATE DB", db_name, db_character_set, db_collation_set,result , messageText);
         ELSE
            SELECT '[Fail] sql_log_bin=OFF is set, so execution is not allowed. Please try after changing to sql_log_bin=ON.' as Message;
            SET messageText='[Fail] sql_log_bin=OFF is set, so execution is not allowed. Please try after changing to sql_log_bin=ON.';
        END IF;
      ELSE
        SELECT '[Fail] Please execute the procedure on the master db server.' as Message;
        SET messageText='[Fail] Please execute the procedure on the master db server.';
    END IF;

END;

