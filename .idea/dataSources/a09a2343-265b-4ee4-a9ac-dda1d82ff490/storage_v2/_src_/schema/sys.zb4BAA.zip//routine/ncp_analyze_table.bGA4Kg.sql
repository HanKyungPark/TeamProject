create
    definer = radmin@localhost procedure ncp_analyze_table(IN DB_NAME varchar(100), IN TABLE_NAME varchar(100))
BEGIN
   DECLARE mysql_version VARCHAR(20);
   DECLARE system_user_yn INT;
   DECLARE called_by_user VARCHAR(50);
   DECLARE priv_yn VARCHAR(5);
   DECLARE v_user VARCHAR(20);
   DECLARE v_host VARCHAR(50);
   DECLARE hostname VARCHAR(50);
   DECLARE result VARCHAR(10);
   DECLARE messageText VARCHAR(400);

   SELECT user() into called_by_user;
   SELECT version() into mysql_version;
   SELECT user, host into v_user, v_host FROM mysql.user WHERE USER() LIKE concat(USER,'@',HOST) ORDER BY LENGTH(HOST) - LENGTH(REPLACE(HOST,'.','')) DESC , substring_index(REPLACE(REPLACE(host,'_',''),'%',''), '.',-1) desc LIMIT 1 ;
   SELECT @@hostname into hostname;

   SET @v_user := v_user;
   SET @v_host := v_host;
   SET @DB_NAME := DB_NAME;
   SET @TABLE_NAME := TABLE_NAME;
   SET result= 'FAIL';

   SET @sql_db:=CONCAT('ANALYZE NO_WRITE_TO_BINLOG TABLE ', @DB_NAME ,'.', @TABLE_NAME);


 SELECT `Repl_slave_priv` FROM mysql.user WHERE user= SUBSTRING_INDEX(user(), '@', 1) AND host= v_host LIMIT 1 INTO priv_yn;

    IF @DB_NAME != 'mysql' THEN
       IF priv_yn ='Y' THEN

                 PREPARE stmt_db FROM @sql_db;
                 EXECUTE stmt_db;
                 SET messageText= CONCAT('[PROCEED] ', @sql_db);
                 SET result= 'PROCEED';

      ELSE
          SELECT '[Fail] You have no authority to Analyze Table. Please try again with an account with DDL privileges.' as Message;
          SET messageText='[Fail] You have no authority to Analyze Table. Please try again with an account with DDL privileges.';
      END IF;
    ELSE
        SELECT '[Fail] This function does not provide ANALYZE TABLE authority for system DB.' as Message;
        SET messageText='[Fail] This function does not provide ANALYZE TABLE authority for system DB.';
    END IF;
    SET sql_log_bin = 0;
    INSERT INTO mysql.ncp_db_history (`hostname`, `version`, `called_by_user`, `action`, `db_name`,  `result`, `message`) values ( hostname, mysql_version, called_by_user, "ANALYZE TABLE", '', result , CONCAT("ANALYZE TABLE ", DB_NAME, ".", TABLE_NAME , " / " ,messageText));
    SET sql_log_bin = 1;
 END;

